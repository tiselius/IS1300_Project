/*
 * test.h
 *
 *  Created on: Nov 16, 2023
 *      Author: arontiselius
 */

#ifndef INC_TEST_H_
#define INC_TEST_H_

void tester();
void led_test();
void car_sw_test();
void blinking();
void flag_tester();
void timer_tester();
void traffic_sequence();
void pedestrian_test();


#endif /* INC_TEST_H_ */
